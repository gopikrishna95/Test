package com.example.test.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.function.Predicate;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.test.DTO.SupplyDTO;
import com.example.test.model.Supply;

@RestController
@RequestMapping("/updateSupply")
public class SupplyController {
	
	@GetMapping
	public ResponseEntity<SupplyDTO> getUpdateSupply(@RequestBody SupplyDTO inputSupply){
		
		SupplyDTO supplyRecord=new SupplyDTO();
		supplyRecord.setProductId(inputSupply.getProductId());
		supplyRecord.setUpdateTimeStamp(inputSupply.getUpdateTimeStamp());
		supplyRecord.setQuantity(inputSupply.getQuantity());
	
		System.out.println("input time :" + inputSupply.getUpdateTimeStamp().toLocalTime());
		ArrayList<Supply> supplyList=new ArrayList<Supply>();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSX");
	         supplyList.add( new Supply("Product1", LocalDateTime.parse("2021-03-16T08:53:48.616Z".replace("T", " "), format), 10.0));
	         supplyList.add( new Supply("Product2", LocalDateTime.parse("2021-03-16T08:59:48.616Z".replace("T", " "), format),  5.0));
	         supplyList.add( new Supply("Product3", LocalDateTime.parse("2021-03-16T09:10:48.616Z".replace("T", " "), format),  30.0));
	         supplyList.add( new Supply("Product4", LocalDateTime.parse("2021-03-16T09:10:48.616Z".replace("T", " "), format), 20.0));
	         
		Predicate<Supply> pred=(p)->p.getProductId().equalsIgnoreCase(inputSupply.getProductId());
		Predicate<Supply> pred2=(p)->p.getUpdateTimeStamp().isBefore(inputSupply.getUpdateTimeStamp());
		Predicate<Supply> pred3=(p)->p.getUpdateTimeStamp().isAfter(inputSupply.getUpdateTimeStamp());

		for(Supply s:supplyList) {
			if(pred.and(pred2).test(s)) {
				supplyRecord.setQuantity((int) (s.getQuantity()+inputSupply.getQuantity()));
				supplyRecord.setStatus("Updated");
			}else if(pred.and(pred3).test(s)) {
				supplyRecord.setStatus("Out Of Sync Update");
			}
		}
		return ResponseEntity.ok(supplyRecord);
		
				
	}

}