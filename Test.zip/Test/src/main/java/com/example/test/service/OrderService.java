package com.example.test.service;

import java.time.LocalDate;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountedCompleter;
import java.util.function.Predicate;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.test.DTO.OrderInput;
import com.example.test.model.Order;
import com.example.test.model.Shipment;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OrderService {
	
	@Async
	public CompletableFuture<Order> getOrderDetails(OrderInput orderInput){
	
		Order order=new Order("Order1", "Prod1", 2.0);
		
		Order orderResponse=new Order();
		
		Predicate<Order> pred=(o)->o.getOrderId().equalsIgnoreCase(orderInput.getOrderId());
		
		log.info("getOrderDetails :" + Thread.currentThread().getName());
		
		if(pred.test(order))
		{
			orderResponse.setOrderId(order.getOrderId());
			orderResponse.setProductId(order.getProductId());
			orderResponse.setQty(order.getQty());
		
		}
		return CompletableFuture.completedFuture(orderResponse);
		
		
	}
	
	@Async
	public CompletableFuture<Shipment> getShipmentDetails(OrderInput orderInput){
		
		Shipment shipment=new Shipment("Order1","Ship1","Prod1",LocalDate.of(2021, 02, 19),2.0);
		
		Shipment shipmentRes=new Shipment();
		Predicate<Shipment> shippred=(s)->s.getOrderI().equalsIgnoreCase(orderInput.getOrderId());
		log.info("getShipmentDetails :" + Thread.currentThread().getName());

		if(shippred.test(shipment)) {
			
			shipmentRes.setProductId(shipment.getProductId());
			shipmentRes.setQty(shipment.getQty());
			shipmentRes.setShipmentDate(shipment.getShipmentDate());
			shipmentRes.setShipmentId(shipment.getShipmentId());
			shipmentRes.setProductId(shipment.getProductId());
		}
		return CompletableFuture.completedFuture(shipmentRes);
	
	}

}
