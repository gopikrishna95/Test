package com.example.test.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Shipment {

	@JsonIgnore
	private String orderI;
	private String shipmentId;
	private String productId;
	private LocalDate shipmentDate;
	private Double qty;

}
