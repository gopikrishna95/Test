package com.example.test.service;

import java.util.ArrayList;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

import com.example.test.DTO.SupplyDemandDto;
import com.example.test.model.Demand;
import com.example.test.model.SupplyQ2;

@Service
public class SupplyDemandService {
	
	public SupplyQ2 getSupply(SupplyDemandDto inputSupply) {
		
		ArrayList<SupplyQ2> supplyList=new ArrayList<SupplyQ2>();		
		supplyList.add(new SupplyQ2("Product1",10));
		supplyList.add(new SupplyQ2("Product2",5));
		
		SupplyQ2 supplyRes=new SupplyQ2();

		Predicate<SupplyQ2> supPred=(s)->s.getProductId().equalsIgnoreCase(s.getProductId());
		
		for(SupplyQ2 sup: supplyList) {
			if(supPred.test(sup)) {
				
				supplyRes.setProductId(sup.getProductId());
				supplyRes.setQuantity(sup.getQuantity());
			}
		}
		
		return supplyRes;
		
	}
public Demand getDemand(SupplyDemandDto inputSupply) {
		
		ArrayList<Demand> supplyList=new ArrayList<Demand>();		
		supplyList.add(new Demand("Product1",10));
		supplyList.add(new Demand("Product2",5));
		
		Demand demandRes=new Demand();

		Predicate<Demand> supPred=(s)->s.getProductId().equalsIgnoreCase(s.getProductId());
		
		for(Demand sup: supplyList) {
			if(supPred.test(sup)) {
				
				demandRes.setProductId(sup.getProductId());
				demandRes.setQuantity(sup.getQuantity());
			}
		}
		
		return demandRes;
		
	}

}
