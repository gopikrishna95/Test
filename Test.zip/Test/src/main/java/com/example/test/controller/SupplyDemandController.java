package com.example.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.test.DTO.SupplyDemandDto;
import com.example.test.model.Demand;
import com.example.test.model.SupplyQ2;
import com.example.test.service.SupplyDemandService;

@RestController
@RequestMapping("/getAvailability")
public class SupplyDemandController {
	
	@Autowired
	SupplyDemandService supplyService;
	
	@GetMapping
	public ResponseEntity<SupplyDemandDto> getAvailability(@RequestBody SupplyDemandDto inputSupply) {
		
		
		SupplyQ2 supply= supplyService.getSupply(inputSupply);
		Demand demand= supplyService.getDemand(inputSupply);

		SupplyDemandDto supplydemandres=new SupplyDemandDto();
		supplydemandres.setProductId(inputSupply.getProductId());
		int AvailableQuantity=supply.getQuantity()-demand.getQuantity();
		if(AvailableQuantity>0) {
			supplydemandres.setAvailability(AvailableQuantity);
		}else {
			supplydemandres.setAvailability(AvailableQuantity);
		}
		return ResponseEntity.ok(supplydemandres);
		
		
	}

}
