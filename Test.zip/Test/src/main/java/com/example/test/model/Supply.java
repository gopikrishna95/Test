package com.example.test.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Supply {

	private String productId;
	private LocalDateTime updateTimeStamp;
	private Double quantity;
}