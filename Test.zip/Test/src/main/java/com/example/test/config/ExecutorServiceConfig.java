package com.example.test.config;

import java.util.concurrent.Executor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class ExecutorServiceConfig {
	
	
	@Bean("executor")
	public Executor executor() {
		
		ThreadPoolTaskExecutor tptk= new ThreadPoolTaskExecutor();
		tptk.setCorePoolSize(Runtime.getRuntime().availableProcessors());
		tptk.setQueueCapacity(1000);
		tptk.setThreadNamePrefix("Thread Name : ");
		tptk.initialize();
		
		return tptk;
	}

}
