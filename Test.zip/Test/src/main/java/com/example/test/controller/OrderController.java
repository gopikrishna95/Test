package com.example.test.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.test.DTO.OrderDto;
import com.example.test.DTO.OrderInput;
import com.example.test.model.Order;
import com.example.test.model.Shipment;
import com.example.test.service.OrderService;

@RestController
@RequestMapping("/getOrderDetails")
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@GetMapping
	public OrderDto getOrderShipmentDetails(@RequestBody OrderInput orderInput) {
		
		CompletableFuture<Order> order=orderService.getOrderDetails(orderInput);
		CompletableFuture<Shipment>  shipment=orderService.getShipmentDetails(orderInput);
		
		OrderDto orderDTO=new OrderDto();
		
		try {
			orderDTO.setOrder(order.get());
			orderDTO.setShipment(shipment.get());
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		return orderDTO;
		
	}

}
