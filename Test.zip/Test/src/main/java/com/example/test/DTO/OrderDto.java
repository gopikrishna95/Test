package com.example.test.DTO;

import com.example.test.model.Order;
import com.example.test.model.Shipment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDto {
	
	private Order order;
	private Shipment shipment;

}
